////
////  Bridging header.h
////  SecondHandBuy
////
////  Created by Kithin Yeung on 18-02-16.
////  Copyright © 2016 Kithin en Stephanie. All rights reserved.
////
//
//#ifndef Bridging_header_h
//#define Bridging_header_h
//
//#import <Parse/Parse.h>
//#import <ParseUI/ParseUI.h>
//#import <Bolts/Bolts.h>
//
//#endif /* Bridging_header_h */
