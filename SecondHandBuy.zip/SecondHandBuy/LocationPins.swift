//
//  LocationPins.swift
//  SecondHandBuy
//
//  Created by Stephanie on 23/02/16.
//  Copyright © 2016 Kithin en Stephanie. All rights reserved.
//

//import Foundation
//import Mapkit
//import UIKit
